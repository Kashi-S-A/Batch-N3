package com.ksa.pfm.service.impl;

import com.ksa.pfm.service.UserService;

public class UserServiceImpl implements UserService {

}
