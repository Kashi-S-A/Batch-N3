package com.ksa.pfm.service;

public interface BudgetService {

}
