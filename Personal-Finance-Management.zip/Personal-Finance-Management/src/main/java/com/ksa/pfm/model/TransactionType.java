package com.ksa.pfm.model;

public enum TransactionType {

	INCOME, EXPENSE
}
