package com.ksa.pfm.service.impl;

import com.ksa.pfm.service.BudgetService;

public class BudgetServiceImpl implements BudgetService {

}
